#!/bin/bash

tmux a -t Ses$1

exit 0
