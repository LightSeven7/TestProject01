#!/bin/bash

tmux new -s Ses$1

exit 0

