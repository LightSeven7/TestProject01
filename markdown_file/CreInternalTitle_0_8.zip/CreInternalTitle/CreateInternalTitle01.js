'use strict';

chrome.extension.onRequest.addListener(
    function(request, sender, sendResponse) {

        // let li_first = $('.widget-antennaList-title:first').text();
        let li_first = CreateTitle();

        if (request.greeting == 'hello') {
            sendResponse({
                farewell: 'OK',
                title: li_first
            });
        } else {
            //★ここ重要★ レスポンスがない場合でも、必ず空のオブジェクトを返す。
            sendResponse({
                farewell: 'NG'
            });
        }
    }
);

// 月日が一桁の場合、頭に０を付ける 例)8→08
const countNum = (num) => {
    num = num + '';
    if (num.length === 1) num = '0' + num;
    return num;
};

const CreateTitle = () => {

    // const holidayDates = ['2020/08/10','2020/08/11','2020/09/21','2020/09/22','2020/11/03','2020/11/23'];
    let dt = new Date();
    let month, date, next = '', day;
    let dateT = ['日','月','火','水','木','金','土'];
    let businessDay = 3;
    let dayCounter = 0;

    // ３営業日後が土日であれば、日付を＋１
    for (let i = 0; i < businessDay; i++) {

        dt.setDate(dt.getDate() + 1);
        day = dateT[dt.getDay()];

        if (day == '土' || day == '日') {
            dayCounter++;
        }
    }

    if (dayCounter > 0) dt.setDate(dt.getDate() + dayCounter);

    // ３営業日後の日付を取得
    month = dt.getMonth() + 1;
    date = dt.getDate();
    day = dateT[dt.getDay()];
    next = countNum(month) + countNum(date);

    let temp = 'aaaい/ああ';
    temp = temp.split('/').join('／');

    var li_first;
    li_first = $('.widget-antennaList-title:first').text();

    return 'Next ' + next + '(' + day + ')-' + dayCounter + '\n' + li_first;
};

// #------------------------------------------------------------------


// メニューをクリック時に実行
// chrome.contextMenus.onClicked.addListener(item => {

//     // バージョン確認
//     // ;;; console.log('jQuery: ', $().jQuery);

//     // var $ = jQuery.noConflict(true);

//     // 月日が一桁の場合、頭に０を付ける 例)8→08
//     const countNum = (num) => {
//         num = num + '';
//         if (num.length === 1) num = '0' + num;
//         return num;
//     };

//     // const holidayDates = ['2020/08/10','2020/08/11','2020/09/21','2020/09/22','2020/11/03','2020/11/23'];
//     let dt = new Date();
//     let month, date, next = '', day;
//     let dateT = ['日','月','火','水','木','金','土'];
//     let businessDay = 3;
//     let dayCounter = 0;

//     // ３営業日後が土日であれば、日付を＋１
//     dt.setDate(dt.getDate() + 1);
//     for (let i = 0; i < businessDay; i++) {
//         day = dateT[dt.getDay()];
//         if (day == '土') {
//             dayCounter++;
//         } else if (day == '日') {
//             dayCounter++;
//         }

//         dt.setDate(dt.getDate() + 1);
//     }

//     if (dayCounter > 0) dt.setDate(dt.getDate() + dayCounter);

//     // ３営業日後の日付を取得
//     month = dt.getMonth() + 1;
//     date = dt.getDate();
//     day = dateT[dt.getDay()];
//     next = countNum(month) + countNum(date);

//     let temp = 'aaaい/ああ';
//     temp = temp.split('/').join('／');

//     var li_first;
//     li_first = $('.widget-antennaList-title:first').text();

//     // alert('Next ' + next + '(' + day + ')' + ':' + temp);
//     alert('Next ' + next + '(' + day + ') :' + li_first + ':' + temp);

//     // alert('Create Internal Title');
//     // console.log(item);
//     // console.log(item.menuItemId);

// });
