#include "stdafx.h"
#include "NativeFunc.h"

using namespace Native;

void FuncClass::Max(int* src, int num, int* mx, int* mxIndex)
{
    *mx = src[0];
    *mxIndex = 0;

    for (int i = 0; i < num; i++) {
        if (src[i] > *mx) {
            *mxIndex = i;
            *mx = src[i];
        }
    }
}

void FuncClass::GetResultValue(const wchar_t* portName,
                                const int charSize, double* resultValue)
{
    try {
        // �|�[�g�ԍ��̌^�ϊ�
        setlocale(LC_CTYPE, "ja_JP.UTF-8");

//        std::string strPortName;
//        std::wstring wstrPortName = std::wstring(&portName[charSize]);

        CString csPortName;
        csPortName.SetString(portName);

//        csPortName.SetString(&portName[charSize]);
//        csPortName.SetString(wstrPortName.c_str());

        SerialPortTran serialPortTran = SerialPortTran(csPortName);
        *resultValue = serialPortTran.GetResultValue();

    } catch (...) {
        *resultValue = -1;
    }

    return;
}