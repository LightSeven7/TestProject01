﻿namespace test02
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.formsPlot1 = new ScottPlot.FormsPlot();
            this.graphTimer = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnRecvStart = new System.Windows.Forms.Button();
            this.btnRecvStop = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPortReSearch = new System.Windows.Forms.Button();
            this.cmbPortName = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // formsPlot1
            // 
            this.formsPlot1.ForeColor = System.Drawing.Color.Black;
            this.formsPlot1.Location = new System.Drawing.Point(1, 183);
            this.formsPlot1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.formsPlot1.Name = "formsPlot1";
            this.formsPlot1.Size = new System.Drawing.Size(713, 555);
            this.formsPlot1.TabIndex = 2;
            // 
            // graphTimer
            // 
            this.graphTimer.Interval = 1000;
            this.graphTimer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.button1.Location = new System.Drawing.Point(856, 692);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 42);
            this.button1.TabIndex = 3;
            this.button1.Text = "終了";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("IPAexゴシック", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBox1.Location = new System.Drawing.Point(748, 183);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(252, 294);
            this.textBox1.TabIndex = 4;
            // 
            // btnRecvStart
            // 
            this.btnRecvStart.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRecvStart.Location = new System.Drawing.Point(748, 496);
            this.btnRecvStart.Name = "btnRecvStart";
            this.btnRecvStart.Size = new System.Drawing.Size(104, 42);
            this.btnRecvStart.TabIndex = 5;
            this.btnRecvStart.Text = "受信開始";
            this.btnRecvStart.UseVisualStyleBackColor = true;
            this.btnRecvStart.Click += new System.EventHandler(this.btnRecvStart_Click);
            // 
            // btnRecvStop
            // 
            this.btnRecvStop.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRecvStop.Location = new System.Drawing.Point(896, 496);
            this.btnRecvStop.Name = "btnRecvStop";
            this.btnRecvStop.Size = new System.Drawing.Size(105, 42);
            this.btnRecvStop.TabIndex = 6;
            this.btnRecvStop.Text = "受信停止";
            this.btnRecvStop.UseVisualStyleBackColor = true;
            this.btnRecvStop.Click += new System.EventHandler(this.btnRecvStop_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(632, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "ポート";
            // 
            // btnPortReSearch
            // 
            this.btnPortReSearch.Font = new System.Drawing.Font("IPAexゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnPortReSearch.Location = new System.Drawing.Point(927, 138);
            this.btnPortReSearch.Name = "btnPortReSearch";
            this.btnPortReSearch.Size = new System.Drawing.Size(73, 22);
            this.btnPortReSearch.TabIndex = 9;
            this.btnPortReSearch.Text = "再検索";
            this.btnPortReSearch.UseVisualStyleBackColor = true;
            this.btnPortReSearch.Click += new System.EventHandler(this.btnPortReSearch_Click);
            // 
            // cmbPortName
            // 
            this.cmbPortName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPortName.Font = new System.Drawing.Font("IPAexゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbPortName.FormattingEnabled = true;
            this.cmbPortName.Location = new System.Drawing.Point(681, 138);
            this.cmbPortName.Name = "cmbPortName";
            this.cmbPortName.Size = new System.Drawing.Size(242, 22);
            this.cmbPortName.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1012, 740);
            this.Controls.Add(this.cmbPortName);
            this.Controls.Add(this.btnPortReSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRecvStop);
            this.Controls.Add(this.btnRecvStart);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.formsPlot1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private ScottPlot.FormsPlot formsPlot1;
        private System.Windows.Forms.Timer graphTimer;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnRecvStart;
        private System.Windows.Forms.Button btnRecvStop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPortReSearch;
        private System.Windows.Forms.ComboBox cmbPortName;
    }
}

