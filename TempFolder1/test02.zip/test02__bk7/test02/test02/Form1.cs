﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Wrapper;
using ScottPlot;
using System.Threading;
using System.Threading.Tasks;
using System.Management;
using System.Collections.Generic;

namespace test02
{
    public partial class Form1 : Form
    {
        // ポート名格納用リスト
        private List<string> PortList = new List<string>();
        
        private List<MeasureDetail> measureList = new List<MeasureDetail>();

        // 舌圧計測値取得クラス
        WrapperClass wr = new WrapperClass();

        // 動的にポイントを追加できるScatterPointListを作成します。
        ScottPlot.Plottable.ScatterPlotList<double> pointList
            = new ScottPlot.Plottable.ScatterPlotList<double>();

        // 波形の生成に使うカウンタです
        int counter = 0;
        double point = 0.0;

        // スレッド管理用の各変数群
        private bool StopFlag = false;
        private string val = "";
        private Task t1;



        public Form1()
        {
            InitializeComponent();

            InitGraphDrawing(); // ScottPlotライブラリによるグラフ描画初期処理
        }

        // フォームロードイベント
        private void Form1_Load(object sender, EventArgs e)
        {
            // ポート番号を取得し、コンボボックスへ表示する
            GetPortNameList();
        }

        // タイマーイベント
        private void timer1_Tick(object sender, EventArgs e)
        {
            // pointListにデータを追加します。
            // 既にコントロールにも追加しているので、ここで追加したデータもRender()の際に合わせて表示されます
            MeasureDetail oneData = new MeasureDetail();
            int listSize = measureList.Count - 1;
            if (listSize < 0)
            {
                oneData.RealScore = 0;
            } else
            {
                oneData = measureList[listSize];
            }

            string dispTime = oneData.RealTime.ToString("HH:mm:ss");
            DateTime dt = DateTime.Parse(dispTime);
            pointList.Add(dt.ToOADate(), oneData.RealScore);

            pointList.Color = Color.SkyBlue;

            // ポイントデータに合わせて表示範囲を自動調整します。
            formsPlot1.Plot.AxisAuto();

            // X軸を日付とするように、設定します
            formsPlot1.Plot.XAxis.DateTimeFormat(true);

            // コントロールをpointListで描画します
            formsPlot1.Render();

        }

        // 終了ボタン押下イベント
        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        // 受信開始ボタン押下イベント
        private void btnRecvStart_Click(object sender, EventArgs e)
        {
            try {
                // グラフ描画用タイマーを開始する
                graphTimer.Start();

                // ポート名からポート番号を取得する
                string portNumber = getPortNumber(cmbPortName.Text);

                List<MeasureDetail> measureDetailList = new List<MeasureDetail>();

                //*** スレッド内処理 ***//
                Action<object> action = (object obj) => {
                    // １ミリ秒単位で舌圧計測値を取得し１秒内で最も大きい数値を１秒単位での計測値とする
                    do {

                        string sPortName = obj.ToString();
                        char[] chPortName = sPortName.ToCharArray();
                        double resultValue = 0;
                        wr.GetResultValue(chPortName, chPortName.Length, ref resultValue);

                        // 計測値をリストに格納する
                        MeasureDetail measureDetail = new MeasureDetail(DateTime.Now, resultValue);

                        // 今回取得した計測時間
                        string CurrentTime = measureDetail.RealTime.ToString("HH:mm:ss");

                        int listCount = measureDetailList.Count();
                        if (listCount > 0) {
                            MeasureDetail md = measureDetailList[listCount - 1];
                            string beforeTime = md.RealTime.ToString("HH:mm:ss");
                            if (string.Compare(CurrentTime, beforeTime) == 1) {
                                // 前回の時分秒内で最も大きな計測値を取得する
                                measureDetailList.Add(measureDetail);
                                double sameSecondVal = measureDetailList.Select(x => x.RealScore).Max();

                                //　非同期で処理されるので直接UIにアクセスできないのでInvokeをつかって処理
                                val = beforeTime + "： " + sameSecondVal + "\r\n";
                                this.Invoke((Action)(() => this.textBox1.AppendText(val))); // 確認用(後で削除)
                                this.Invoke((Action)(() => this.measureList.Add(new MeasureDetail(md.RealTime, sameSecondVal))));
                            }
                        }
                        measureDetailList.Clear();
                        measureDetailList.Add(measureDetail);

                        counter++;
                        Thread.Sleep(1);

                    } while (StopFlag);
                };

                //*** スレッド開始 ***//
                StopFlag = true;
                t1 = new Task(action, portNumber);
                t1.Start();

            } catch (Exception ex) {
                Console.WriteLine(ex.Message);
            }
        }

        // 受信停止ボタン押下イベント
        private void btnRecvStop_Click(object sender, EventArgs e)
        {
            try {
                StopFlag = false;
                t1.Wait();
                t1.Dispose();

                textBox1.Text += "Loop Stop";
                graphTimer.Stop();

            } catch (Exception ex) {
                Console.WriteLine(ex.Message);
            }
        }

        // ポート名一覧の取得
        private bool GetPortNameList()
        {
            bool retval = false;
            int i = 0;

            try {
                cmbPortName.Items.Clear();

                // 接続済みデバイス確認
                ManagementClass device = new ManagementClass("Win32_PnPEntity");

                // ポート名&COM番号取得
                foreach (ManagementObject port in device.GetInstances()) {
                    // ポート名を取得して、「"(COM"」に一致する文字列数の確認
                    string name = (string)port.GetPropertyValue("Name");
                    // "(COM" に一致する文字列数確認
                    if (!string.IsNullOrEmpty(name) && name.IndexOf("(COM") >= 0) {
                        // 取得したポート名とCOM番号をセット
                        cmbPortName.Items.Add(port.GetPropertyValue("Caption"));
                        // "COM*"を取り出して配列に追加
                        PortList.Add(name.Substring(i + 1).Replace(")", ""));
                    }
                }
                // 選択項目の一番上を表示する
                if (cmbPortName.Items.Count > 0) cmbPortName.SelectedIndex = 0;

                // 処理正常終了
                retval = true;

            } catch (Exception ex) {
                Console.WriteLine("getPortNameList: " + ex.Message);
                retval = false;
            }

            return retval;
        }

        private void btnPortReSearch_Click(object sender, EventArgs e)
        {
            // List配列 全項目削除
            PortList.RemoveRange(0, PortList.Count);
            // デバイス再読込
            GetPortNameList();
        }

        // ポート名からポート番号を取得する
        private string getPortNumber(string _portName)
        {
            string portNumber = "";

            try {
                // ポート名選択チェック
                if (string.IsNullOrEmpty(cmbPortName.Text)) {
                    MessageBox.Show("シリアル通信可能なUSBケーブルが接続されていません。");
                    return "";
                }

                // ポート名からポート番号のみを取り出す
                int index = cmbPortName.Text.IndexOf("COM");
                int indexEnd = cmbPortName.Text.Length - 1;
                portNumber = cmbPortName.Text.Substring(index, (indexEnd - index));
                return portNumber;

            } catch (Exception e) {
                MessageBox.Show("ポート番号を取得する際に異常が発生しました。\r\n" + "処理を中断します。");
                return "";
            }
        }

        private void InitGraphDrawing()
        {
            try {
                formsPlot1.Plot.Style(Style.Black);
                formsPlot1.Plot.Palette = ScottPlot.Palette.Aurora;
                formsPlot1.Plot.Palette = ScottPlot.Palette.PolarNight;

                //            formsPlot1.Plot.Title("舌圧計測");
                formsPlot1.Plot.XLabel("時間(時分秒)");
                formsPlot1.Plot.YLabel("圧力値");
                // formsPlot1.Plot.Legend();
                formsPlot1.Plot.SaveFig("style_Black.png");

                // 目盛線の間隔を設定します。
                //float pointX = 0.20F;
                //float pointY = 1.00F;
                //formsPlot1.Plot.XAxis.SetOffset(pointX);
                //formsPlot1.Plot.YAxis.SetOffset(pointY);
                formsPlot1.Plot.XAxis.ManualTickSpacing(1);
                formsPlot1.Plot.YAxis.ManualTickSpacing(1);

                formsPlot1.Plot.Grid(color: Color.FromArgb(50, Color.Green));
                formsPlot1.Plot.Grid(lineStyle: LineStyle.Dot);
//                formsPlot1.Plot.m

                formsPlot1.Plot.YAxis.MajorGrid(lineWidth: 1, lineStyle: LineStyle.Solid, color: Color.Aqua);

                // ScottPlotのコントロールに、ScatterPointListを追加します。
                formsPlot1.Plot.Add(pointList);
                formsPlot1.Refresh();

            } catch (Exception e) {
                MessageBox.Show("グラフ描画処理で異常が発生しました。\r\n" + "処理を中断します。");
            }
        }
    }
}