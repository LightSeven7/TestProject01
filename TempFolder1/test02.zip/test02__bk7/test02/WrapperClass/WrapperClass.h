#pragma once
#include "..\NativeFunc\NativeFunc.h"
using namespace System;
using namespace System::Runtime::InteropServices;
using namespace System::Collections::Generic;

namespace Wrapper
{
    public ref class WrapperClass
    {
    private:
        Native::FuncClass* _na0; //���������|�C���g
    public:
        WrapperClass();
        ~WrapperClass();
        !WrapperClass();
        void Max(array<int>^ src, int num, int% mx, int% mxIndex);
        void GetResultValue(array<Char>^, const int, double%);

    }; //end class
} //end namespace
