﻿// SerialPortTest_MFC06Dlg.cpp : 実装ファイル
//
#include "pch.h"
#include "framework.h"
#include "SerialPortTest_MFC06.h"
#include "SerialPortTest_MFC06Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSerialPortTestMFC06Dlg ダイアログ
CSerialPortTestMFC06Dlg::CSerialPortTestMFC06Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_SERIALPORTTEST_MFC06_DIALOG, pParent)
	, m_cRecvData(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_SerialHandle = NULL;
	m_bStopFlag = FALSE;
	m_pThread = NULL;
	m_DigitCounter = 0;
	m_CurrValue = '\0';
}

void CSerialPortTestMFC06Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_eMeasureVal);
	DDX_Control(pDX, ID_BUTTON1, m_bRecvStart);
	DDX_Control(pDX, ID_BUTTON2, m_bRecvStop);
	DDX_Control(pDX, ID_BUTTON3, m_bAppQuit);
	DDX_Text(pDX, IDC_EDIT1, m_cRecvData);
}

BEGIN_MESSAGE_MAP(CSerialPortTestMFC06Dlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_BUTTON1, &CSerialPortTestMFC06Dlg::OnBnClickedButton1)
	ON_BN_CLICKED(ID_BUTTON2, &CSerialPortTestMFC06Dlg::OnBnClickedButton2)
	ON_BN_CLICKED(ID_BUTTON3, &CSerialPortTestMFC06Dlg::OnBnClickedButton3)
	ON_MESSAGE(WM_COPYDATA, &CSerialPortTestMFC06Dlg::OnCopydata)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CSerialPortTestMFC06Dlg メッセージ ハンドラー
BOOL CSerialPortTestMFC06Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// このダイアログのアイコンを設定します。アプリケーションのメイン ウィンドウがダイアログでない場合、
	//  Framework は、この設定を自動的に行います。
	SetIcon(m_hIcon, TRUE);			// 大きいアイコンの設定
	SetIcon(m_hIcon, FALSE);		// 小さいアイコンの設定

	return TRUE;  // フォーカスをコントロールに設定した場合を除き、TRUE を返します。
}

// ダイアログに最小化ボタンを追加する場合、アイコンを描画するための
//  下のコードが必要です。ドキュメント/ビュー モデルを使う MFC アプリケーションの場合、
//  これは、Framework によって自動的に設定されます。
void CSerialPortTestMFC06Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 描画のデバイス コンテキスト

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// クライアントの四角形領域内の中央
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// アイコンの描画
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// ユーザーが最小化したウィンドウをドラッグしているときに表示するカーソルを取得するために、
//  システムがこの関数を呼び出します。
HCURSOR CSerialPortTestMFC06Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

// 受信開始ボタン押下イベント
void CSerialPortTestMFC06Dlg::OnBnClickedButton1()
{
	m_bStopFlag = FALSE;

	// シリアル通信の初期化処理
	if (InitSerial()) {
		m_bRecvStart.EnableWindow(FALSE);
		m_bRecvStop.EnableWindow(TRUE);
		m_bAppQuit.EnableWindow(FALSE);

		// スレッドにて読み込み処理を実行
		m_pThread
			= AfxBeginThread(ThreadReciveSerialData, this, 0, 0, CREATE_SUSPENDED);
		m_pThread->m_bAutoDelete = FALSE;
		m_pThread->ResumeThread();

		// 5ms毎にタイマーイベント(OnTimer)実行
		CWnd::SetTimer(1, 5, NULL);
	}
}

// 受信停止ボタン押下イベント
void CSerialPortTestMFC06Dlg::OnBnClickedButton2()
{
	m_bStopFlag = TRUE;
	m_bRecvStart.EnableWindow(TRUE);
	m_bRecvStop.EnableWindow(FALSE);
	m_bAppQuit.EnableWindow(TRUE);
	UninitSerial();
}

// 終了ボタン押下イベント
void CSerialPortTestMFC06Dlg::OnBnClickedButton3()
{
	if (m_SerialHandle) UninitSerial();
	CDialogEx::OnOK();
}

/**
 * @brief シリアル通信の初期化処理を行います。
 * @return 処理結果 TRUE:成功/FALSE:失敗
 */
BOOL CSerialPortTestMFC06Dlg::InitSerial()
{
	// シリアルポートをオープンする。
	m_SerialHandle = CreateFile(
		_T("COM3"),
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);

	// シリアルポートがオープンできない場合は終了
	if (m_SerialHandle == INVALID_HANDLE_VALUE) return FALSE;

	// シリアルポートの通信条件を取得する
	DCB dcb;
	ZeroMemory(&dcb, sizeof(dcb));

	// シリアルポートの通信条件が取得できない場合は終了
	if (!GetCommState(m_SerialHandle, &dcb)) {
		return UninitSerial();
	}

	// シリアル通信の入出力バッファをクリアする
	PurgeComm(m_SerialHandle,
		PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);

	// シリアルポートの通信条件を設定する
	SetSerialPortSettings(&dcb);

	// シリアル通信の設定をする
	if (!SetCommState(m_SerialHandle, &dcb)) {
		return UninitSerial();
	}

	// シリアル通信のタイムアウトパラメータを取得する
	COMMTIMEOUTS timeouts;
	ZeroMemory(&timeouts, sizeof(timeouts));

	// シリアル通信のタイムアウトパラメータの取得でエラーの場合は終了
	if (!GetCommTimeouts(m_SerialHandle, &timeouts)) {
		return UninitSerial();
	}

	// シリアル通信のタイムアウトパラメータを再設定する
	SetTimeoutSettings(&timeouts);

	// シリアル通信のタイムアウトパラメータの再設定でエラーの場合は終了
	if (!SetCommTimeouts(m_SerialHandle, &timeouts)) {
		return UninitSerial();
	}

	// シリアル通信の拡張機能を設定します。
	EscapeCommFunction(m_SerialHandle, SETRTS);

	return TRUE;
}

// シリアルポートの通信条件を設定
void CSerialPortTestMFC06Dlg::SetSerialPortSettings(DCB* dcb)
{
	dcb->fBinary = TRUE;
	dcb->BaudRate = 19200;
	dcb->fParity = FALSE;
	dcb->Parity = NOPARITY;
	dcb->ByteSize = 8;
	dcb->StopBits = ONESTOPBIT;
	dcb->fOutxCtsFlow = FALSE;
	dcb->fOutxDsrFlow = FALSE;
	dcb->fDsrSensitivity = FALSE;
	dcb->fTXContinueOnXoff = FALSE;
	dcb->fOutX = FALSE;
	dcb->fInX = FALSE;
	dcb->fDtrControl = DTR_CONTROL_ENABLE;
	dcb->fRtsControl = RTS_CONTROL_HANDSHAKE;
	dcb->fNull = FALSE;
	dcb->EofChar = '\r\n';
}

// シリアル通信のタイムアウトパラメータを再設定
void CSerialPortTestMFC06Dlg::SetTimeoutSettings(COMMTIMEOUTS* timeouts)
{
	timeouts->ReadIntervalTimeout = MAXDWORD;
	timeouts->ReadTotalTimeoutMultiplier = 0;
	timeouts->ReadTotalTimeoutConstant = 10000;
	timeouts->WriteTotalTimeoutMultiplier = 0;
	timeouts->WriteTotalTimeoutConstant = 10;
}

/**
 * @brief シリアル通信の終了処理を行います。
 * @return 処理結果 TRUE:成功/FALSE:失敗 ※ここでは常に成功としています。
 */
BOOL CSerialPortTestMFC06Dlg::UninitSerial()
{
	try {
		// シリアルのハンドルをクローズする
		CloseHandle(m_SerialHandle);
		m_SerialHandle = NULL;
	} catch (...) {
		if (m_SerialHandle) m_SerialHandle = NULL;
	}
	return FALSE;
}

// タイマーイベント
void CSerialPortTestMFC06Dlg::OnTimer(UINT_PTR nIDEvent)
{
	DWORD result = WaitForSingleObject(m_pThread->m_hThread, 0);
	if (result == WAIT_ABANDONED || result == WAIT_OBJECT_0) {
		CWnd::KillTimer(1);
		m_bRecvStart.EnableWindow(TRUE);
		m_bRecvStop.EnableWindow(FALSE);
		m_bAppQuit.EnableWindow(TRUE);
		delete m_pThread;
	}

	CDialogEx::OnTimer(nIDEvent);
}

// スレッド実行
UINT CSerialPortTestMFC06Dlg::ThreadReciveSerialData(LPVOID pParam)
{
	CSerialPortTestMFC06Dlg* pDlg = (CSerialPortTestMFC06Dlg*)pParam;

	do {
		// 受信データを1バイト読み出す
		char achar = 0;
		DWORD dwRead = 0;
		BOOL bRet = ReadFile(pDlg->m_SerialHandle,
			(LPVOID)&achar, 1, &dwRead, NULL);

		// 受信データの読み出しでエラーの場合
		if (!bRet) {
			// エラーをクリアして、終了します。
			ULONG portError = 0;
			COMSTAT cs;
			ZeroMemory(&cs, sizeof(cs));
			ClearCommError(pDlg->m_SerialHandle, &portError, &cs);
			break;
		}

		// 受信データがある場合
		if (dwRead > 0) {
			BYTE recvData[1];
			recvData[0] = '\0';
			recvData[0] = achar;

			COPYDATASTRUCT data;
			memset(&data, 0, sizeof(data));
			data.dwData = 0;
			data.lpData = recvData;
			data.cbData = sizeof(recvData);

			// 受信データをUIに反映する
			pDlg->SendMessage(WM_COPYDATA, 0, (LPARAM)&data);
		}

	} while (!pDlg->m_bStopFlag);

	return 0;
}

/**
 * @brief OnCopyDataメッセージが送信された時に呼び出されます。
 * @param [in] wParam パラメータ
 * @param [in] lParam パラメータ
 * @return 処理結果 0:成功/0以外:失敗
 */
afx_msg LRESULT CSerialPortTestMFC06Dlg::OnCopydata(WPARAM wParam, LPARAM lParam)
{
	m_DigitCounter++;

	// 取得した受信データを受信データ表示用テキストボックスに追加します。
	COPYDATASTRUCT* pData = (COPYDATASTRUCT*)lParam;
	PVOID pRecvData = (PVOID)pData->lpData;
	CString recvData;
	recvData.Format(_T("%S"), pRecvData);

	// 6文字分のデータを取得したら計測値として画面へ表示する
	if (m_DigitCounter != 6) {
		m_CurrValue += recvData;

	} else if (m_DigitCounter == 6) {
		// 倍精度浮動小数点型に変換してから単位を揃える
		double calcValue = _tstof(m_CurrValue);
		if (calcValue < 1) {
			calcValue = 0;
		} else if (calcValue > 1) {
			calcValue /= 10;
			calcValue = round_n(calcValue, 2);
		}
		std::string calcStrValue = std::to_string(calcValue);

		// 舌圧の計測時間と計測値を取得
		m_ScoreDetail scoreDetail;
		for (int i = 0; i < calcStrValue.size(); i++) {
			if (calcStrValue.at(i) == '.') {
				scoreDetail.real_time = CTime::GetCurrentTime().Format("%H:%M:%S");
				scoreDetail.real_score = calcStrValue.substr(0, i + 2).c_str();
				break;
			}
		}

		// あれば前回計測時間を取得する
		CString preTime;
		if (m_ScoreList.size() > 0) {
			preTime = m_ScoreList.back().real_time;
		} else {
			preTime = scoreDetail.real_time;
		}

		// 今回の計測時間(時分秒)が前回より新しければ、前回計測値を画面に表示する
		if (preTime.Compare(scoreDetail.real_time) < 0) {
			// 前回の同一時間内の最大計測情報を取得して画面表示用に編集する
			SetDisplayData(MaxValueWithinSameTime());
			m_ScoreList.clear();
		}

		m_ScoreList.push_back(scoreDetail);
		m_DigitCounter = 0;
		m_CurrValue = "";
	}

	return 0;
}

// 指定した小数点で四捨五入
double CSerialPortTestMFC06Dlg::round_n(double& number, const int n)
{
	number = number * pow(10, n - 1); // 四捨五入したい値を10の(n-1)乗倍する。
	number = round(number);		// 小数点以下を四捨五入する。
	number /= pow(10, n - 1);	// 10の(n-1)乗で割る。
	return number;
}

void CSerialPortTestMFC06Dlg::SetDisplayData(m_ScoreDetail& maxScoreData)
{
	CString data = m_cRecvData.GetString();
	data += maxScoreData.real_time + _T("　　：");
	data += maxScoreData.real_score + _T("\r\n");

	m_cRecvData.SetString(data);
	m_ScoreList_Official.push_back(maxScoreData);
	UpdateData(FALSE);

	// エディットボックスに文字が表示されたら、最大行数分スクロールさせて最新の文字が見えるようにする
	CEdit* edit = (CEdit*)GetDlgItem(IDC_EDIT1);
	if (edit != NULL) edit->LineScroll(edit->GetLineCount());
	return;
}

// 同一時間(時分秒)内の最大計測情報を取得
CSerialPortTestMFC06Dlg::m_ScoreDetail CSerialPortTestMFC06Dlg::MaxValueWithinSameTime()
{
	std::list <m_ScoreDetail>::iterator scoreList_itr;
	std::string maxScoreValue;

	// リストの１件目の計測値を初期値として設定する
	double real_score_max = _tstof(m_ScoreList.begin()->real_score);
	real_score_max = round_n(real_score_max, 2);

	// 同一の時分秒内の計測値で最大値を取得する
	for (scoreList_itr = m_ScoreList.begin();
		scoreList_itr != m_ScoreList.end(); scoreList_itr++) {

		double real_score_cur = _tstof(scoreList_itr->real_score);
		real_score_cur = round_n(real_score_cur, 2);

		maxScoreValue
			= real_score_max < real_score_cur
			? std::to_string(real_score_cur).c_str()
			: std::to_string(real_score_max).c_str();
	}

	// 計測値の小数点第三位以降を切り捨てる
	for (int i = 0; i < maxScoreValue.size(); i++) {
		if (maxScoreValue.at(i) == '.') {
			maxScoreValue = maxScoreValue.substr(0, i + 2);
			if (maxScoreValue == "0.0") maxScoreValue = " 0.0";

			if (maxScoreValue.size() < 4) {
				maxScoreValue = " " + maxScoreValue;
			}
			break;
		}
	}

	m_ScoreDetail retScoreData;
	retScoreData.real_time = m_ScoreList.begin()->real_time;
	retScoreData.real_score = maxScoreValue.c_str();

	return retScoreData;
}
