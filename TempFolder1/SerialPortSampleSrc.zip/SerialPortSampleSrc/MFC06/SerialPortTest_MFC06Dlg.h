﻿// SerialPortTest_MFC06Dlg.h : ヘッダー ファイル
//
#pragma once
#include <memory>
#include <list>
#include <string>
#include <exception>
#include <functional>

// CSerialPortTestMFC06Dlg ダイアログ
class CSerialPortTestMFC06Dlg : public CDialogEx
{
// コンストラクション
public:
	CSerialPortTestMFC06Dlg(CWnd* pParent = nullptr);	// 標準コンストラクター

// ダイアログ データ
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SERIALPORTTEST_MFC06_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV サポート

// 実装
protected:
	HICON m_hIcon;

	// 生成された、メッセージ割り当て関数
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	DECLARE_MESSAGE_MAP()

private:
	HANDLE m_SerialHandle;
	BOOL m_bStopFlag;
	int m_DigitCounter;
	CString m_CurrValue;

	typedef struct _ScoreDetail {
		CString real_time;
		CString real_score;
	} m_ScoreDetail;

	std::list<m_ScoreDetail> m_ScoreList;
	std::list<m_ScoreDetail> m_ScoreList_Official;

	BOOL InitSerial();
	BOOL UninitSerial();
	void SetSerialPortSettings(DCB*);
	void SetTimeoutSettings(COMMTIMEOUTS*);
	void SetDisplayData(m_ScoreDetail&);
	double round_n(double&, const int);
	m_ScoreDetail MaxValueWithinSameTime();
	static UINT ThreadReciveSerialData(LPVOID);

public:
	CEdit m_eMeasureVal;
	CWinThread* m_pThread;
	CButton m_bRecvStart;
	CButton m_bRecvStop;
	CButton m_bAppQuit;

protected:
	afx_msg LRESULT OnCopydata(WPARAM wParam, LPARAM lParam);

public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CString m_cRecvData;
};
