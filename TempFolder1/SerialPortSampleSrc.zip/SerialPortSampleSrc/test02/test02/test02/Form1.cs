﻿extern alias MySQLClient;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Wrapper;
using ScottPlot;
using System.Threading;
using System.Threading.Tasks;
using System.Management;
using System.Collections.Generic;
using System.Diagnostics;

namespace test02
{
    public partial class Form1 : Form
    {
        // 舌圧計測値取得クラス
        WrapperClass wr = new WrapperClass();

        // 状態通知メッセージ
        private string notifyWord = "";

        // ポート名格納用リスト
        private List<string> PortList = new List<string>();

        // 動的にポイントを追加できるScatterPointListを作成します。
        private List<MeasureDetail> measureList = new List<MeasureDetail>();
        private ScottPlot.Plottable.ScatterPlotList<double> pointList
            = new ScottPlot.Plottable.ScatterPlotList<double>();

        private double[] liveData = new double[50];
        private int arrayPin = 0;

        // リアルタイム描画用
        DataGen.Electrocardiogram ecg = new DataGen.Electrocardiogram();
        Stopwatch sw = Stopwatch.StartNew();

        // スレッド管理用の各変数群
        private bool StopFlag = false;
        private string val = "";
        private Task t1;
        private double maxMeasureVal = 0;
        private double onceMaxVal = 0;
        private int countVal = 0;
        private double beforeVal = 1;


        public Form1()
        {
            InitializeComponent();

            InitGraphDrawing();     // 全体グラフ描画初期設定
            InitGraphDrawingSed();  // 詳細グラフ描画初期設定
            InitFormDisplay();      // 画面の各コントロール初期設定
        }

        // フォームロードイベント
        private void Form1_Load(object sender, EventArgs e)
        {
            // ポート番号を取得し、コンボボックスへ表示する
            GetPortNameList();
        }

        // タイマーイベント
        private void timer1_Tick(object sender, EventArgs e)
        {
            // pointListにデータを追加します。
            // 既にコントロールにも追加しているので、ここで追加したデータもRender()の際に合わせて表示されます
            MeasureDetail oneData = new MeasureDetail();

            int listSize = measureList.Count - 1;
            if (listSize < 0) return;
            else {
                // 最大計測値判定
                oneData = measureList[listSize];
                if (oneData.RealScore > maxMeasureVal) {
                    maxMeasureVal = oneData.RealScore;
                    onceMaxVal = oneData.RealScore;
                    if (countVal == 1) txtMaxValue1st.Text = onceMaxVal.ToString();
                    else if (countVal == 2) txtMaxValue2nd.Text = onceMaxVal.ToString();
                    else if (countVal == 3) txtMaxValue3rd.Text = onceMaxVal.ToString();
                }

                // 計測回数ごとの最高値を画面に表示する
                if (oneData.RealScore > onceMaxVal) {
                    onceMaxVal = oneData.RealScore;
                    if (countVal == 1) txtMaxValue1st.Text = onceMaxVal.ToString();
                    else if (countVal == 2) txtMaxValue2nd.Text = onceMaxVal.ToString();
                    else if (countVal == 3) txtMaxValue3rd.Text = onceMaxVal.ToString();
                }
            }

            // 計測回数をカウント
            if (beforeVal == 0 && oneData.RealScore == 0) {
                // 前回も計測値ゼロで今回も計測値ゼロの場合は、カウントしない
                beforeVal = oneData.RealScore;

            } else if (beforeVal > 0 && oneData.RealScore == 0) {
                // 前回は計測値ありで今回計測値ゼロの場合、計測回数＋１
                if (countVal < 4) countVal++;
                txtMeasureCount.Text = countVal.ToString();
                beforeVal = 0;
                onceMaxVal = 0;

            } else {
                beforeVal = oneData.RealScore;
            }

            pointList.Add(DateTime.Parse(oneData.RealTime).ToOADate(), oneData.RealScore);
            pointList.Color = Color.Ivory;

            // ポイントデータに合わせて表示範囲を自動調整します。
            formsPlot1.Plot.AxisAuto();
            pointList.LineWidth = 1;

            // X軸を日付とするように、設定します
            formsPlot1.Plot.XAxis.DateTimeFormat(true);

            // コントロールをpointListで描画します
            formsPlot1.Render();

        }

        // 終了ボタン押下イベント
        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        // 受信開始ボタン押下イベント
        private void btnRecvStart_Click(object sender, EventArgs e)
        {
            try {
                // グラフ描画用タイマーを開始する
                graphTimer.Start();

                sw.Start();
                //timerRender.Start();
                //timerUpdateData.Start();

                timerRender.Enabled = true;
                timerUpdateData.Enabled = true;

                // ポート名からポート番号を取得する
                string portNumber = getPortNumber(cmbPortName.Text);

                List<MeasureDetail> measureDetailList = new List<MeasureDetail>();

                //*** スレッド内処理 ***//
                Action<object> action = (object obj) => {
                    // １ミリ秒単位で舌圧計測値を取得し１秒内で最も大きい数値を１秒単位での計測値とする
                    do {
                        string msg;
                        char[] chPortName = obj.ToString().ToCharArray();
                        double resultValue = 0;
                        wr.GetResultValue(chPortName, chPortName.Length, ref resultValue);

                        if (resultValue < 0) {
                            switch (resultValue)
                            {
                                case -1:
                                    msg = "シリアル通信接続時にエラーが発生しました。";
                                    break;
                                case -2:
                                    msg = "計測値取得中にエラーが発生しました。";
                                    break;
                                case -3:
                                    msg = "想定外のエラーが発生しました。";
                                    break;
                                default:
                                    msg = "";
                                    break;  // 正常
                            }
                            this.Invoke((Action)(() => this.notifyWord = msg));
                            break;
                        }

                        // 計測値をリストに格納する
                        MeasureDetail measureDetail = new MeasureDetail(DateTime.Now.ToString("HH:mm:ss.fff"), resultValue);

                        // 今回取得した計測時間
                        string CurrentTime = measureDetail.RealTime.Substring(0, measureDetail.RealTime.LastIndexOf("."));
                        string CurMilliSed = measureDetail.RealTime.Substring(measureDetail.RealTime.LastIndexOf(".") + 1);

                        // 前回までに取得したデータの件数(1/500秒単位)を取得する
                        int listCount = measureDetailList.Count();

                        // 前回取得したデータを取得する
                        MeasureDetail md = new MeasureDetail();
                        string beforeTime = "";
                        string beforeMilliSed = "";
                        if (listCount == 0) md = measureDetail;
                        else if (listCount > 0) md = measureDetailList[listCount - 1];

                        beforeTime = md.RealTime.Substring(0, md.RealTime.LastIndexOf("."));
                        beforeMilliSed = md.RealTime.Substring(md.RealTime.LastIndexOf(".") + 1);

                        if (string.Compare(CurrentTime, beforeTime) == 0
                            && int.Parse(beforeMilliSed) < 500 && int.Parse(CurMilliSed) >= 500)
                        {

                            // 前回の時分秒内で最も大きな計測値を取得する
                            double sameSecondVal = measureDetailList.Select(x => x.RealScore).Max();
                            if (this.StopFlag)
                            {
                                //　非同期で処理されるので直接UIにアクセスできないのでInvokeをつかって処理
                                this.Invoke((Action)(() => this.measureList.Add(new MeasureDetail(md.RealTime, sameSecondVal))));
                                val = beforeTime + "： " + sameSecondVal + "\r\n";           // 確認用(後で削除)
                                this.Invoke((Action)(() => this.textBox1.AppendText(val))); // 確認用(後で削除)
                                measureDetailList.Clear();
                            }

                        }
                        else if (string.Compare(CurrentTime, beforeTime) == 1)
                        {
                            // 前回の時分秒内で最も大きな計測値を取得する
                            double sameSecondVal = measureDetailList.Select(x => x.RealScore).Max();
                            if (this.StopFlag)
                            {
                                //　非同期で処理されるので直接UIにアクセスできないのでInvokeをつかって処理
                                this.Invoke((Action)(() => this.measureList.Add(new MeasureDetail(md.RealTime, sameSecondVal))));
                                val = beforeTime + "： " + sameSecondVal + "\r\n";           // 確認用(後で削除)
                                this.Invoke((Action)(() => this.textBox1.AppendText(val))); // 確認用(後で削除)
                                measureDetailList.Clear();
                            }
                        }

                        ////　非同期で処理されるので直接UIにアクセスできないのでInvokeをつかって処理
                        //this.Invoke((Action)(() => this.measureList.Add(new MeasureDetail(md.RealTime, measureDetail.RealScore))));

                        measureDetailList.Add(measureDetail);
                        Thread.Sleep(1);
                    } while (this.StopFlag);
                };

                //*** スレッド開始 ***//
                StopFlag = true;
                t1 = new Task(action, portNumber);
                t1.Start();

                // スレッド内でエラーメッセージが設定されていた場合に取得する
                if (!string.IsNullOrEmpty(notifyWord)) {
                    MessageBox.Show(notifyWord + "\r\n" + "舌圧計との通信中にエラーが発生しました。画面を初期状態へ戻します。");
                    InitFormDisplay();
                }

            } catch (Exception ex) {
                string msg = "受信処理中に異常が発生しました。";
                msg += ex.Message;
                MessageBox.Show(msg);
                Console.WriteLine(msg);
            }
        }

        // 受信停止ボタン押下イベント
        private void btnRecvStop_Click(object sender, EventArgs e)
        {
            try {
                StopFlag = false;
                t1.Wait();
                t1.Dispose();

                textBox1.Text += "Loop Stop";
                graphTimer.Stop();

                sw.Stop();
                if (timerRender.Enabled) timerRender.Enabled = false;
                if (timerUpdateData.Enabled) timerUpdateData.Enabled = false;

            } catch (Exception ex) {
                string msg = "受信停止処理中に異常が発生しました。";
                msg += ex.Message;
                MessageBox.Show(msg);
                Console.WriteLine(msg);
            }
        }

        // ポート名一覧の取得
        private bool GetPortNameList()
        {
            bool retval = false;
            int i = 0;

            try {
                cmbPortName.Items.Clear();

                // 接続済みデバイス確認
                ManagementClass device = new ManagementClass("Win32_PnPEntity");
                // ポート名&COM番号取得
                foreach (ManagementObject port in device.GetInstances()) {
                    // ポート名を取得して、「"(COM"」に一致する文字列数の確認
                    string name = (string)port.GetPropertyValue("Name");
                    // "(COM" に一致する文字列数確認
                    if (!string.IsNullOrEmpty(name) && name.IndexOf("(COM") >= 0) {
                        // 取得したポート名とCOM番号をセット
                        cmbPortName.Items.Add(port.GetPropertyValue("Caption"));
                        // "COM*"を取り出して配列に追加
                        PortList.Add(name.Substring(i + 1).Replace(")", ""));
                    }
                }
                // 選択項目の一番上を表示する
                if (cmbPortName.Items.Count > 0) cmbPortName.SelectedIndex = 0;

                // 処理正常終了
                retval = true;

            } catch (Exception ex) {
                Console.WriteLine("getPortNameList: " + ex.Message);
                retval = false;
            }

            return retval;
        }

        // PCで使用されているポート名を再取得する
        private void btnPortReSearch_Click(object sender, EventArgs e)
        {
            // List配列 全項目削除
            PortList.RemoveRange(0, PortList.Count);
            // デバイス再読込
            GetPortNameList();
        }

        // ポート名からポート番号を取得する
        private string getPortNumber(string _portName)
        {
            string portNumber = "";

            try {
                // ポート名選択チェック
                if (string.IsNullOrEmpty(cmbPortName.Text)) {
                    MessageBox.Show("シリアル通信可能なUSBケーブルが接続されていません。");
                    return "";
                }

                // ポート名からポート番号のみを取り出す
                int index = cmbPortName.Text.IndexOf("COM");
                int indexEnd = cmbPortName.Text.Length - 1;
                portNumber = cmbPortName.Text.Substring(index, (indexEnd - index));
                return portNumber;

            } catch (Exception e) {
                MessageBox.Show("ポート番号を取得する際に異常が発生しました。\r\n" + "処理を中断します。");
                return "";
            }
        }

        // 全体表示用グラフ描画 - 初期処理
        private void InitGraphDrawing()
        {
            try {
                //* 全体テーマ
                formsPlot1.Plot.Style(Style.Blue3);

                // ラベル
                formsPlot1.Plot.XLabel("時間(時分秒)");
                formsPlot1.Plot.YLabel("圧力値");
                // formsPlot1.Plot.Legend();

                // 目盛線の間隔を設定します。
                formsPlot1.Plot.XAxis.ManualTickSpacing(1);
                formsPlot1.Plot.YAxis.ManualTickSpacing(5);

                formsPlot1.Plot.AxisAutoX(margin: 0);
                formsPlot1.Plot.AddHorizontalLine(y: 30, color: Color.GreenYellow, width: 1, style: LineStyle.Solid);

//                formsPlot1.Plot.Grid(color: Color.FromArgb(50, Color.Red));
                formsPlot1.Plot.Grid(lineStyle: LineStyle.Dot);
                
                formsPlot1.Plot.SetAxisLimits(xMin: 0, xMax: 30);
                formsPlot1.Plot.SetAxisLimits(yMin: -0.5, yMax: 45);

                formsPlot1.Plot.XAxis.MajorGrid(lineWidth: 1, lineStyle: LineStyle.Dot, color: Color.Orange);
                formsPlot1.Plot.YAxis.MajorGrid(lineWidth: 1, lineStyle: LineStyle.Dot, color: Color.Orange);

                // ScottPlotのコントロールに、ScatterPointListを追加します。
                formsPlot1.Plot.Add(pointList);
                formsPlot1.Refresh();

            } catch (Exception e) {
                string msg = "全体表示用グラフ描画処理で異常が発生しました。\r\n";
                msg += "処理を中断します。";
                msg += e.Message;
                MessageBox.Show(msg);
            }
            return;
        }

        // 詳細表示用グラフ描画 - 初期処理
        private void InitGraphDrawingSed()
        {
            try {
                formsPlot2.Plot.Style(Style.Blue1);

                formsPlot2.Plot.AddSignal(liveData, color: Color.Ivory);
                //formsPlot2.Plot.AxisAutoX(margin: 0);
                //formsPlot2.Plot.AxisAutoY(margin: 0);
                formsPlot2.Plot.XAxis.ManualTickSpacing(10);
                formsPlot2.Plot.SetAxisLimits(yMin: 0, yMax: 50);
                formsPlot2.Plot.AddHorizontalLine(y: 30, color: Color.GreenYellow, width: 1, style: LineStyle.Solid);

                formsPlot2.Plot.XAxis.MajorGrid(lineWidth: 1, lineStyle: LineStyle.Dot, color: Color.Orange);
                formsPlot2.Plot.YAxis.MajorGrid(lineWidth: 1, lineStyle: LineStyle.Dot, color: Color.Orange);

                formsPlot2.Plot.Title("Electrocardiogram Strip Chart");
                formsPlot2.Plot.YLabel("Potential (mV)");
                formsPlot2.Plot.XLabel("Time (seconds)");

                formsPlot2.Plot.Grid(false);

                Closed += (sender, args) =>
                {
                    timerUpdateData?.Stop();
                    timerRender?.Stop();
                };

            }
            catch (Exception e) {
                string msg = "詳細表示用グラフ描画処理で異常が発生しました。\r\n";
                msg += "処理を中断します。";
                msg += e.Message;
                MessageBox.Show(msg);
            }
            return;
        }

        // 画面の状態を初期表示へ戻す
        private void InitFormDisplay()
        {
            this.txtPromoterName.Text = "";
            this.txtPatientId.Text = "";
            this.txtPatientName.Text = "";
            this.txtMaxValue1st.Text = "0.0";
            this.txtMaxValue2nd.Text = "0.0";
            this.txtMaxValue3rd.Text = "0.0";
            this.txtTargetValue.Text = "30.0";
            this.txtMeasureCount.Text = "0";
            this.textBox1.Clear();
            this.formsPlot1.Refresh();
            this.formsPlot2.Refresh();

            maxMeasureVal = 0;
            countVal = 0;
            StopFlag = false;
            onceMaxVal = 0;
            arrayPin = 0;
            GetPortNameList();

            return;
        }

        // リセットボタン押下イベント
        private void btnReset_Click(object sender, EventArgs e)
        {
            InitFormDisplay();
        }

        private void txtPatientId_TextChanged(object sender, EventArgs e)
        {
            if (txtPatientId.TextLength == 10) {

                string kenshinId = txtPatientId.Text;
                DateTime dt = DateTime.Parse(dtMeeting.Text);
                string kenshinDate = dt.ToString("yyyy-MM-dd");
                if (!GetFrailInfo(kenshinDate, kenshinId)) {
                    DateTime targetDate = DateTime.Parse(dtMeeting.Text);
                    DateTime currentDate = DateTime.Now;
                    string msg = "";
                    if (targetDate.Date.CompareTo(currentDate.Date) == 0) {
                        msg = "本日のフレイル健診で受付が済んでいないか、未登録です。";
                    } else if (targetDate.Date.CompareTo(currentDate.Date) == -1) {
                        msg = kenshinDate + "のフレイル健診は受けていません。";
                    }
                    MessageBox.Show(msg);
                    return;
                }
            } else if (txtPatientId.TextLength < 10) {
                return;
            } else if (txtPatientId.TextLength > 10) {
                string msg = "入力された健診者IDが10桁を超えています。\r\n";
                msg += "再入力してください。\r\n";
                msg += "入力されたID： " + txtPatientId.Text;
                MessageBox.Show(msg);
                txtPatientId.Text = "";
            }
        }

        // AWSフレイルDBアクセス
        private bool GetFrailInfo(string kenshinDate, string kenshinId)
        {
            bool retVal = false;
            try {
                List<string> PatientList = FrailRdsAccess.PatientBaseInfo(kenshinDate, kenshinId);
                if (PatientList.Count > 0) {
                    txtPatientId.Text = PatientList[0];
                    txtPatientName.Text = PatientList[1];
                    txtPromoterName.Text = PatientList[2];
                    retVal = true;
                }
                // SSH秘密鍵によるDBアクセス
                // bool bbb = DBHelper.GetRDSConnection_SSH(); ※作成中
            } catch (Exception e) {
                MessageBox.Show("DB接続でエラーが発生しました。\r\n" + e.Message.ToString());
            }
            return retVal;
        }

        int nextValueIndex = -1;
        private void timerUpdateData_Tick(object sender, EventArgs e)
        {
            if (arrayPin > 700) {
                return;
            }

            MeasureDetail oneData = new MeasureDetail();
            if (measureList.Count - 1 < 0) return;
            else oneData = measureList[measureList.Count - 1];

            int count = 0;
            if (liveData.Length == 0) count = 0;
            else count = liveData.Length - 1;

            if (count <= 50) {
                liveData[count] = oneData.RealScore;
            } else if (count > 50) {
                liveData = liveData.Resize(count + 1);
                liveData = liveData.Add(oneData.RealScore);
            }

            double nextValue = ecg.GetVoltage(sw.Elapsed.TotalSeconds);
            Array.Copy(liveData, 1, liveData, 0, liveData.Length - 1);
            liveData[liveData.Length - 1] = nextValue;

            arrayPin++;
        }

        private void timerRender_Tick(object sender, EventArgs e)
        {
            formsPlot2.Refresh();
        }

    }
}
