﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test02
{
    internal class MeasureDetail
    {
        private string realTime;
        private double realScore;

        // コンストラクタ
        public MeasureDetail() { }

        public MeasureDetail(string _realTime, Double _realScore) {
            realTime = _realTime;
            realScore = _realScore;
        }

        public string RealTime {
            get { return realTime; }
            set { realTime = value; }
        }
        public Double RealScore {
            get { return realScore; }
            set { realScore = value; }
        }

    }
}
