﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test02
{
    internal static class Utility
    {
        // 配列の要素数の変更
        public static T[] Resize<T>(this T[] array, int newSize)
        {
            Array.Resize(ref array, newSize);
            return array;
        }

        // 配列を+1して最後にデータを追加
        public static T[] Add<T>(this T[] array, T item)
        {
            Array.Resize(ref array, array.Length + 1);
            array[array.Length - 1] = item;
            return array;
        }
    }
}
