﻿extern alias MySQLClient;

using System;
using System.Configuration;
using Renci.SshNet;
using System.Text;
using MySql.Data;
using MySQLClient::MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace test02
{
    internal class FrailRdsAccess
    {
        private static MySqlConnection m_Con;

        private static bool RDSConnection()
        {
            try {
                // 接続に必要なパラメータ文字列を生成する
                string server = "frail-dev.cfpc1xgnuqud.ap-northeast-1.rds.amazonaws.com";
                string database = "frail";
                string user = "frailuser";
                string pass = "alphaAs01";
                string charset = "utf8";
                string connectionString = string.Format("Server={0};Database={1};Uid={2};Pwd={3};Charset={4}", server, database, user, pass, charset);

                // コネクション作成
                m_Con = new MySqlConnection(connectionString);
                m_Con.Open();           // 接続開始

            } catch (MySqlException ex) {
                Console.WriteLine(ex);  // 接続時に異常発生
                return false;
            }
            return true;
        }

        private static bool RDSClose()
        {
            try {
                m_Con.Close();
            } catch (MySqlException ex) {
                Console.WriteLine(ex);  // 切断時に異常発生
                return false;
            }
            return true;
        }

        private static StringBuilder SetPatientInfoQuery()
        {
            StringBuilder query = new StringBuilder();
            query.AppendLine("select distinct mpt.promoter_cd pmt_cd, ");
            query.AppendLine("    convert(AES_DECRYPT(UNHEX(mpt.promoter_name), 'H4y3ubwE') USING utf8) pmt_name,");
            query.AppendLine("    mp.patient_no pid,");
            query.AppendLine("    convert(AES_DECRYPT(UNHEX(mp.patient_name), 'H4y3ubwE') USING utf8) name, ");
            query.AppendLine("    convert(AES_DECRYPT(UNHEX(mp.patient_kana), 'H4y3ubwE') USING utf8) kana, ");
            query.AppendLine("    mp.patient_birth birth, ");
            query.AppendLine("    mp.patient_sex gender,");
            query.AppendLine("    re.examine_pdt, ");
            query.AppendLine("    re.examine_phhmm ");
            query.AppendLine("from mst_patient mp ");
            query.AppendLine("    ,result_examine re ");
            query.AppendLine("    ,mst_promoter mpt ");
            query.AppendLine("    ,mst_examine me ");
            query.AppendLine("where mp.patient_no = re.patient_no ");
            query.AppendLine("and mpt.promoter_cd = re.promoter_cd ");
            query.AppendLine("and mpt.promoter_cd = me.promoter_cd");
            query.AppendLine("and re.examine_pdt = @KenshiDate ");
            query.AppendLine("and re.patient_no = @KenshinId ");
            return query;
        }

        public static List<string> PatientBaseInfo(string kensinDate, string kenshinId)
        {
            List<string> list = new List<string>();

            // SQL文生成
            string query = SetPatientInfoQuery().ToString();

            // DB接続
            RDSConnection();

            // 接続・SQL実行に必要なインスタンスを生成
            using (m_Con)
            using (var command = new MySqlCommand(query, m_Con)) 
            {
                command.Parameters.Add(new MySqlParameter("KenshiDate", kensinDate));
                command.Parameters.Add(new MySqlParameter("KenshinId", kenshinId));

                // SELECT文の実行
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read()) {     // １レコードずつ取得
                        list.Add(reader["pid"].ToString());
                        list.Add(reader["name"].ToString());
                        list.Add(reader["pmt_name"].ToString());
                    }
                }
            }

            // DB切断
            RDSClose();

            return list;
        }

        public static bool GetRDSConnection_SSH()
        {

            try {
                // 接続先のホスト名またはIPアドレス
                var hostNameOrIpAddr = "ec2-52-193-249-36.ap-northeast-1.compute.amazonaws.com";
                // 接続先のポート番号
                var portNo = 22;
                // ログインユーザー名
                var userName = "ec2-user";
                // ログインパスワード
                var passWord = "alphaAs01";

                string path = "C:\\kubota_dev\\Code_Sample\\SerialPortTest\\test02\\test02\\test02\\alpha_frail_dev_key.ppk";
                string path_ = "\\alpha_frailty_key.ppk";
                var pkeyfile = new PrivateKeyFile(path_);

                // コネクション情報
                ConnectionInfo info = new ConnectionInfo(hostNameOrIpAddr, portNo, userName,
                    new AuthenticationMethod[] {
                        /*new PasswordAuthenticationMethod(userName, passWord)*/
                        new PrivateKeyAuthenticationMethod(userName, pkeyfile)
                        /* PrivateKeyAuthenticationMethod("キーの場所")を指定することでssh-key認証にも対応しています */
                    }
                );

                // クライアント作成
                SshClient ssh = new SshClient(info);

                // 接続開始
                ssh.Connect();

                if (ssh.IsConnected)
                {
                    // 接続に成功した（接続状態である）
                    Console.WriteLine("[OK] SSH Connection succeeded!!");
                }
                else
                {
                    // 接続に失敗した（未接続状態である）
                    Console.WriteLine("[NG] SSH Connection failed!!");
                    return false;
                }

                // 接続終了
                ssh.Disconnect();
            }
            catch (Exception ex)
            {
                // エラー発生時
                Console.WriteLine(ex);
                throw ex;
            }

            return true;
        }

    }
}
