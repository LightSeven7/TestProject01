﻿namespace test02
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.formsPlot1 = new ScottPlot.FormsPlot();
            this.graphTimer = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnRecvStart = new System.Windows.Forms.Button();
            this.btnRecvStop = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTargetValue = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMeasureCount = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPromoterName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtPatientName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPatientId = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtMeeting = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPortReSearch = new System.Windows.Forms.Button();
            this.cmbPortName = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.timerUpdateData = new System.Windows.Forms.Timer(this.components);
            this.timerRender = new System.Windows.Forms.Timer(this.components);
            this.formsPlot2 = new ScottPlot.FormsPlot();
            this.btnReStart = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaxValue1st = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtMaxValue2nd = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtMaxValue3rd = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // formsPlot1
            // 
            this.formsPlot1.AutoScroll = true;
            this.formsPlot1.AutoScrollMargin = new System.Drawing.Size(1, 1);
            this.formsPlot1.AutoScrollMinSize = new System.Drawing.Size(1, 1);
            this.formsPlot1.ForeColor = System.Drawing.Color.Black;
            this.formsPlot1.Location = new System.Drawing.Point(12, 192);
            this.formsPlot1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.formsPlot1.Name = "formsPlot1";
            this.formsPlot1.Size = new System.Drawing.Size(690, 361);
            this.formsPlot1.TabIndex = 2;
            // 
            // graphTimer
            // 
            this.graphTimer.Interval = 500;
            this.graphTimer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.button1.Location = new System.Drawing.Point(784, 822);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 42);
            this.button1.TabIndex = 3;
            this.button1.Text = "終了";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("IPAexゴシック", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBox1.Location = new System.Drawing.Point(726, 192);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(198, 319);
            this.textBox1.TabIndex = 4;
            // 
            // btnRecvStart
            // 
            this.btnRecvStart.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRecvStart.Location = new System.Drawing.Point(623, 678);
            this.btnRecvStart.Name = "btnRecvStart";
            this.btnRecvStart.Size = new System.Drawing.Size(137, 42);
            this.btnRecvStart.TabIndex = 5;
            this.btnRecvStart.Text = "計測開始";
            this.btnRecvStart.UseVisualStyleBackColor = true;
            this.btnRecvStart.Click += new System.EventHandler(this.btnRecvStart_Click);
            // 
            // btnRecvStop
            // 
            this.btnRecvStop.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRecvStop.Location = new System.Drawing.Point(784, 678);
            this.btnRecvStop.Name = "btnRecvStop";
            this.btnRecvStop.Size = new System.Drawing.Size(137, 42);
            this.btnRecvStop.TabIndex = 6;
            this.btnRecvStop.Text = "計測停止";
            this.btnRecvStop.UseVisualStyleBackColor = true;
            this.btnRecvStop.Click += new System.EventHandler(this.btnRecvStop_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSave.Location = new System.Drawing.Point(623, 822);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(137, 42);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "計測値保存";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnReset.Location = new System.Drawing.Point(784, 750);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(137, 42);
            this.btnReset.TabIndex = 12;
            this.btnReset.Text = "リセット";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.Location = new System.Drawing.Point(9, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 21);
            this.label4.TabIndex = 16;
            this.label4.Text = "目標計測値";
            // 
            // txtTargetValue
            // 
            this.txtTargetValue.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTargetValue.Location = new System.Drawing.Point(187, 13);
            this.txtTargetValue.Name = "txtTargetValue";
            this.txtTargetValue.ReadOnly = true;
            this.txtTargetValue.Size = new System.Drawing.Size(70, 28);
            this.txtTargetValue.TabIndex = 17;
            this.txtTargetValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label6.Location = new System.Drawing.Point(326, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 21);
            this.label6.TabIndex = 19;
            this.label6.Text = "計測回数";
            // 
            // txtMeasureCount
            // 
            this.txtMeasureCount.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtMeasureCount.Location = new System.Drawing.Point(435, 141);
            this.txtMeasureCount.Name = "txtMeasureCount";
            this.txtMeasureCount.ReadOnly = true;
            this.txtMeasureCount.Size = new System.Drawing.Size(50, 28);
            this.txtMeasureCount.TabIndex = 20;
            this.txtMeasureCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label5.Location = new System.Drawing.Point(258, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 21);
            this.label5.TabIndex = 21;
            this.label5.Text = "Kps";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label7.Location = new System.Drawing.Point(491, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 21);
            this.label7.TabIndex = 22;
            this.label7.Text = "回";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label8.Location = new System.Drawing.Point(11, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 21);
            this.label8.TabIndex = 23;
            this.label8.Text = "主催者名";
            // 
            // txtPromoterName
            // 
            this.txtPromoterName.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtPromoterName.Location = new System.Drawing.Point(111, 19);
            this.txtPromoterName.Name = "txtPromoterName";
            this.txtPromoterName.ReadOnly = true;
            this.txtPromoterName.Size = new System.Drawing.Size(166, 28);
            this.txtPromoterName.TabIndex = 24;
            this.txtPromoterName.Text = "能代市";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label9.Location = new System.Drawing.Point(287, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 21);
            this.label9.TabIndex = 25;
            this.label9.Text = "健診者名";
            // 
            // txtPatientName
            // 
            this.txtPatientName.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtPatientName.Location = new System.Drawing.Point(385, 58);
            this.txtPatientName.Name = "txtPatientName";
            this.txtPatientName.ReadOnly = true;
            this.txtPatientName.Size = new System.Drawing.Size(208, 28);
            this.txtPatientName.TabIndex = 26;
            this.txtPatientName.Text = "山田　太郎";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label10.Location = new System.Drawing.Point(287, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 21);
            this.label10.TabIndex = 27;
            this.label10.Text = "健診者ID";
            // 
            // txtPatientId
            // 
            this.txtPatientId.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtPatientId.Location = new System.Drawing.Point(385, 18);
            this.txtPatientId.Name = "txtPatientId";
            this.txtPatientId.Size = new System.Drawing.Size(208, 28);
            this.txtPatientId.TabIndex = 1;
            this.txtPatientId.TextChanged += new System.EventHandler(this.txtPatientId_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtMeeting);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtPatientName);
            this.groupBox1.Controls.Add(this.txtPatientId);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtPromoterName);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(315, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(610, 100);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "健診者情報";
            // 
            // dtMeeting
            // 
            this.dtMeeting.CalendarFont = new System.Drawing.Font("IPAexゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.dtMeeting.Font = new System.Drawing.Font("IPAexゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.dtMeeting.Location = new System.Drawing.Point(111, 59);
            this.dtMeeting.Name = "dtMeeting";
            this.dtMeeting.Size = new System.Drawing.Size(166, 25);
            this.dtMeeting.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(11, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 21);
            this.label1.TabIndex = 29;
            this.label1.Text = "健診日時";
            // 
            // btnPortReSearch
            // 
            this.btnPortReSearch.Font = new System.Drawing.Font("IPAexゴシック", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnPortReSearch.Location = new System.Drawing.Point(188, 48);
            this.btnPortReSearch.Name = "btnPortReSearch";
            this.btnPortReSearch.Size = new System.Drawing.Size(104, 26);
            this.btnPortReSearch.TabIndex = 9;
            this.btnPortReSearch.Text = "再検索";
            this.btnPortReSearch.UseVisualStyleBackColor = true;
            this.btnPortReSearch.Click += new System.EventHandler(this.btnPortReSearch_Click);
            // 
            // cmbPortName
            // 
            this.cmbPortName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPortName.Font = new System.Drawing.Font("IPAexゴシック", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbPortName.FormattingEnabled = true;
            this.cmbPortName.Location = new System.Drawing.Point(10, 18);
            this.cmbPortName.Name = "cmbPortName";
            this.cmbPortName.Size = new System.Drawing.Size(282, 24);
            this.cmbPortName.TabIndex = 10;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbPortName);
            this.groupBox2.Controls.Add(this.btnPortReSearch);
            this.groupBox2.Location = new System.Drawing.Point(623, 573);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(298, 79);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ポート情報";
            // 
            // timerUpdateData
            // 
            this.timerUpdateData.Enabled = true;
            this.timerUpdateData.Interval = 500;
            this.timerUpdateData.Tick += new System.EventHandler(this.timerUpdateData_Tick);
            // 
            // timerRender
            // 
            this.timerRender.Enabled = true;
            this.timerRender.Interval = 500;
            this.timerRender.Tick += new System.EventHandler(this.timerRender_Tick);
            // 
            // formsPlot2
            // 
            this.formsPlot2.AutoScroll = true;
            this.formsPlot2.AutoScrollMargin = new System.Drawing.Size(1, 1);
            this.formsPlot2.AutoScrollMinSize = new System.Drawing.Size(1, 1);
            this.formsPlot2.ForeColor = System.Drawing.Color.Black;
            this.formsPlot2.Location = new System.Drawing.Point(12, 573);
            this.formsPlot2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.formsPlot2.Name = "formsPlot2";
            this.formsPlot2.Size = new System.Drawing.Size(580, 299);
            this.formsPlot2.TabIndex = 31;
            // 
            // btnReStart
            // 
            this.btnReStart.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnReStart.Location = new System.Drawing.Point(623, 750);
            this.btnReStart.Name = "btnReStart";
            this.btnReStart.Size = new System.Drawing.Size(137, 42);
            this.btnReStart.TabIndex = 32;
            this.btnReStart.Text = "再計測";
            this.btnReStart.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(9, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 21);
            this.label2.TabIndex = 13;
            this.label2.Text = "最大計測値１回目";
            // 
            // txtMaxValue1st
            // 
            this.txtMaxValue1st.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtMaxValue1st.Location = new System.Drawing.Point(187, 58);
            this.txtMaxValue1st.Name = "txtMaxValue1st";
            this.txtMaxValue1st.ReadOnly = true;
            this.txtMaxValue1st.Size = new System.Drawing.Size(70, 28);
            this.txtMaxValue1st.TabIndex = 14;
            this.txtMaxValue1st.Text = "199.9";
            this.txtMaxValue1st.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(258, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 21);
            this.label3.TabIndex = 15;
            this.label3.Text = "Kps";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label11.Location = new System.Drawing.Point(258, 102);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 21);
            this.label11.TabIndex = 35;
            this.label11.Text = "Kps";
            // 
            // txtMaxValue2nd
            // 
            this.txtMaxValue2nd.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtMaxValue2nd.Location = new System.Drawing.Point(187, 99);
            this.txtMaxValue2nd.Name = "txtMaxValue2nd";
            this.txtMaxValue2nd.ReadOnly = true;
            this.txtMaxValue2nd.Size = new System.Drawing.Size(70, 28);
            this.txtMaxValue2nd.TabIndex = 34;
            this.txtMaxValue2nd.Text = "199.9";
            this.txtMaxValue2nd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label12.Location = new System.Drawing.Point(9, 102);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(171, 21);
            this.label12.TabIndex = 33;
            this.label12.Text = "最大計測値２回目";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label13.Location = new System.Drawing.Point(258, 144);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 21);
            this.label13.TabIndex = 38;
            this.label13.Text = "Kps";
            // 
            // txtMaxValue3rd
            // 
            this.txtMaxValue3rd.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtMaxValue3rd.Location = new System.Drawing.Point(187, 141);
            this.txtMaxValue3rd.Name = "txtMaxValue3rd";
            this.txtMaxValue3rd.ReadOnly = true;
            this.txtMaxValue3rd.Size = new System.Drawing.Size(70, 28);
            this.txtMaxValue3rd.TabIndex = 37;
            this.txtMaxValue3rd.Text = "199.9";
            this.txtMaxValue3rd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label14.Location = new System.Drawing.Point(9, 144);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(171, 21);
            this.label14.TabIndex = 36;
            this.label14.Text = "最大計測値３回目";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(937, 883);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtMaxValue3rd);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtMaxValue2nd);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btnReStart);
            this.Controls.Add(this.formsPlot2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtMeasureCount);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtTargetValue);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMaxValue1st);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnRecvStop);
            this.Controls.Add(this.btnRecvStart);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.formsPlot1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private ScottPlot.FormsPlot formsPlot1;
        private System.Windows.Forms.Timer graphTimer;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnRecvStart;
        private System.Windows.Forms.Button btnRecvStop;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTargetValue;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMeasureCount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPromoterName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtPatientName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtPatientId;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnPortReSearch;
        private System.Windows.Forms.ComboBox cmbPortName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Timer timerUpdateData;
        private System.Windows.Forms.Timer timerRender;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtMeeting;
        private ScottPlot.FormsPlot formsPlot2;
        private System.Windows.Forms.Button btnReStart;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMaxValue1st;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtMaxValue2nd;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtMaxValue3rd;
        private System.Windows.Forms.Label label14;
    }
}

