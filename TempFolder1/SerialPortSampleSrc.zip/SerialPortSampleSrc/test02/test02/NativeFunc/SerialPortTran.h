#pragma once

#include <Windows.h>
#include <memory>
#include <list>
#include <string>
#include <exception>
#include <functional>
#include <cstdlib>
#include <locale.h>
#include "atlstr.h"
#include "atltime.h"

namespace Native
{
	class SerialPortTran
	{
	public:
		HANDLE m_SerialHandle;

		SerialPortTran();
		SerialPortTran(const CString);
		double GetResultValue();

	private:
		CString m_PortName;
		CString m_CurrValue;
		double m_MeasureValue;

		bool PortConnect();
		void PortClose();
		bool RecvMeasureData();
		void SetSerialPortSettings(DCB*);
		void SetTimeoutSettings(COMMTIMEOUTS*);
		bool GetMeasureValue(char*, int*);
		double round_n(double&, const int);
	};
}