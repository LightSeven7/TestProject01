﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Wrapper;
using ScottPlot; // DataGenに使います

namespace test02
{
    public partial class Form1 : Form
    {
        WrapperClass _wr = new WrapperClass(); //WrapperClassのインスタンスを作成

        // 動的にポイントを追加できるScatterPointListを作成します。
        ScottPlot.Plottable.ScatterPlotList<double> pointList = new ScottPlot.Plottable.ScatterPlotList<double>();

        // 波形の生成に使うカウンタです
        int counter = 0;
        double point = 0.0;

        public Form1()
        {
            InitializeComponent();

            //int[] a = { 1, 2, 3, 4, 5, 6, 5, 4, 3, 2 };
            //int mx = 0;
            //int mxIndex = 0;
            //int num = 10;

            //MessageBox.Show("int[] a = { 1, 2, 3, 4, 5, 6, 5, 4, 3, 2 }");

            //_wr.Max(a, num, ref mx, ref mxIndex); //処理実行

            //MessageBox.Show("Max = " + mx.ToString() + ", MaxIndex=" + mxIndex.ToString());

            // Environment.Exit(0);


            formsPlot1.Plot.Style(Style.Blue1);
            formsPlot1.Plot.Palette = ScottPlot.Palette.Aurora;
            formsPlot1.Plot.Palette = ScottPlot.Palette.PolarNight;

            formsPlot1.Plot.Title("舌圧計測");
            formsPlot1.Plot.XLabel("時間");
            formsPlot1.Plot.YLabel("値");
            formsPlot1.Plot.Legend();
            formsPlot1.Plot.SaveFig("style_blue1.png");

            // ScottPlotのコントロールに、ScatterPointListを追加します。
            formsPlot1.Plot.Add(pointList);

            // タイマーの処理を開始します
            timer1.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // 3周期ごとにY軸を初期化して、のこぎり型の波形を生成します。
            if (counter % 3 == 0) { point = 0.0; }

            // pointListにデータを追加します。
            // 既にコントロールにも追加しているので、ここで追加したデータも
            // Render()の際に合わせて表示されます
            pointList.Add(counter, point);
            pointList.Color = Color.Orange;
            pointList.LineStyle = LineStyle.Dot;


            // ポイントデータに合わせて表示範囲を自動調整します。
            formsPlot1.Plot.AxisAuto();

            // コントロールを描画します
            // pointList
            formsPlot1.Render();

            // カウンタの更新です。
            point++;
            counter++;

            // 一定数でグラフを初期化します。
            if (counter > 100)
            {
                pointList.Clear();
                counter = 0;
                point = 0;
            }
        }
    }
}