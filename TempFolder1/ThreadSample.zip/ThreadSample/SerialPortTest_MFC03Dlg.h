﻿// SerialPortTest_MFC03Dlg.h : ヘッダー ファイル
//
#pragma once

#include <iostream>
#include <memory>
#include <chrono>
#include <thread>
#include <string>
#include <utility>
#include <vector>
#include <exception>
#include <functional>
#include <map>
#include <mutex>

using namespace std;

// CSerialPortTestMFC03Dlg ダイアログ
class CSerialPortTestMFC03Dlg : public CDialogEx
{
// コンストラクション
public:
	CSerialPortTestMFC03Dlg(CWnd* pParent = nullptr);	// 標準コンストラクター

// ダイアログ データ
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SERIALPORTTEST_MFC03_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV サポート


// 実装
protected:
	HICON m_hIcon;

	// 生成された、メッセージ割り当て関数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	DECLARE_MESSAGE_MAP()

private:
	HANDLE serialHandle;
	BOOL isRecvThreadTerminated;

	BOOL InitSerial();
	BOOL UninitSerial();
	BOOL PlanTask(shared_ptr<HANDLE>);
	BOOL StartTasks();
	void NoneTask();
	void SetSerialPortSettings(DCB*);
	void SetTimeoutSettings(COMMTIMEOUTS*);

public:
	// 生成された、メッセージ割り当て関数
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg LRESULT OnRecvThreadTerminated(const WPARAM, const LPARAM);

	CEdit A_Value;
	CButton btnEnd;
	afx_msg void OnBnClickedButton1();
};
