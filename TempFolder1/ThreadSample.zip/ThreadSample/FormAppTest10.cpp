﻿// FormAppTest10.cpp : このファイルには 'main' 関数が含まれています。プログラム実行の開始と終了がそこで行われます。
//

#include <iostream>
#include <chrono>
#include <thread>
#include <string>
#include <memory>
#include <utility>
#include <vector>
#include <exception>
#include <functional>
#include <map>
#include <mutex>

using namespace std;
using namespace std::chrono_literals;

int do_something(int a)
{
	throw exception();
	return a == 0 ? 0 : 1;
}

class Addr {
	int a_, b_;
	int r_ = 0;
public:
	Addr(int a, int b) : a_(a), b_(b) {}
	int result() const { return r_; }
	void process() {
		r_ = a_ + b_;
		cout << "exec process: " << r_ << endl;
	}
};


string greeting()
{
	return { "Hello, world!" };
}


void task0()
{
	cout << "This is worker-thread" << endl;
}

void task(shared_ptr<int> sp, unique_ptr<int> up)
{
	// spはコピーされるため参照カウント(use_count)=2
	// upはムーブのみ／コピー不可のunique_ptrポインタ
	cout
		<< *sp << " " << sp.use_count() << endl	// 100 2
		<< *up << endl;							// 200
}


map<thread::id, string> thdname_tbl;
mutex thdname_guard;
thread fork_task(function<void()> task, string name)
{
	thread thd { move(task) };
	{
		lock_guard<mutex> lk{ thdname_guard };
		thdname_tbl[thd.get_id()] = move(name);
	}
	return thd;
}

int main()
{
	//*** スレッド処理の基本 ***//
	//thread thd{ task0 };
	//cout << "This is main-thread" << endl;
	//thd.join();


	//*** スレッドグループ ***//
	//vector<thread> thds;

	//// id=1..5のスレッドを作成
	//for (int id = 0; id <= 5; id++) {
	//	thds.emplace_back([&, id] {
	//		// 新しいスレッドで実行される処理
	//		cout << "Worker#" << id << endl;
	//	});
	//}
	//for (auto& t : thds) {
	//	t.join();
	//}


	//*** 新規スレッド上でのメンバ関数呼び出し
//	Addr adder(1, 2);
//#if 0
//	// メンバ関数へのポインタとオブジェクトへのポインタを渡す
//	thread thd{ &Adder::process, &adder };
//#else
//	// ラムダ式を利用したほうが意図が明確になる
//	thread thd{ [&]{ adder.process(); } };
//#endif
//	cout << "calculating..." << endl;
//	thd.join();


	//*** 別スレッドへの引数値渡し ***//
	//shared_ptr<int> sp = make_shared<int>(100);
	//unique_ptr<int> up = make_unique<int>(200);
	//thread thd { task, sp, move(up) };
	//thd.join();


	//*** スレッド間での戻り値返却 ***//
	//string result;
	//thread thd{ [&] { result = greeting(); } };
	//thd.join();
	//cout << result << endl;


	//*** スレッド休眠 ***//
	//for (int i = 0; i < 10; i++) {
	//	this_thread::sleep_for(100ms);
	//	cout << "." << flush;
	//}
	//cout << " done!" << endl;


	//*** 異なるスレッド間での例外送出 ***//
	//int result = 0;
	//exception_ptr ep;
	//thread thd { [&]{
	//	try {
	//		result = do_something(1);
	//	}
	//	catch (...) {
	//		 ep = current_exception();
	//	}
	//}};
	//thd.join();
	//if (ep) {
	//	cout << "Error End!" << endl;
	//} else {
	//	cout << "Normal End" << endl;
	//}

	//*** スレッドID ***//
	//thdname_tbl[this_thread::get_id()] = "(main)";
	//cout << "end" << endl;
}
