﻿
// SerialPortTest_MFC03Dlg.cpp : 実装ファイル
//

#include "pch.h"
#include "framework.h"
#include "SerialPortTest_MFC03.h"
#include "SerialPortTest_MFC03Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace std;
using namespace std::chrono_literals;

// ユーザ定義メッセージ
#define WM_USER_READ_THREAD_TERMINATE (WM_USER + 100)    // 受信スレッド停止メッセージ

// アプリケーションのバージョン情報に使われる CAboutDlg ダイアログ
class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// ダイアログ データ
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV サポート

// 実装
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
    ON_WM_SYSCOMMAND()
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_MESSAGE(WM_USER_READ_THREAD_TERMINATE, CSerialPortTestMFC03Dlg::OnRecvThreadTerminated)
END_MESSAGE_MAP()

// CSerialPortTestMFC03Dlg ダイアログ
CSerialPortTestMFC03Dlg::CSerialPortTestMFC03Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_SERIALPORTTEST_MFC03_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    serialHandle = NULL;
    isRecvThreadTerminated = FALSE;
}

void CSerialPortTestMFC03Dlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_EDIT1, A_Value);
    DDX_Control(pDX, IDC_BUTTON1, btnEnd);
}

BEGIN_MESSAGE_MAP(CSerialPortTestMFC03Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &CSerialPortTestMFC03Dlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CSerialPortTestMFC03Dlg::OnBnClickedCancel)
    ON_BN_CLICKED(IDC_BUTTON1, &CSerialPortTestMFC03Dlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CSerialPortTestMFC03Dlg メッセージ ハンドラー
BOOL CSerialPortTestMFC03Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// "バージョン情報..." メニューをシステム メニューに追加します。
	// IDM_ABOUTBOX は、システム コマンドの範囲内になければなりません。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// このダイアログのアイコンを設定します。アプリケーションのメイン ウィンドウがダイアログでない場合、
	//  Framework は、この設定を自動的に行います。
	SetIcon(m_hIcon, TRUE);			// 大きいアイコンの設定
	SetIcon(m_hIcon, FALSE);		// 小さいアイコンの設定

    // シリアル通信の初期化処理を実施する(失敗した場合は終了)
    // if (!InitSerial()) return FALSE;

    isRecvThreadTerminated = FALSE;

	return TRUE;  // フォーカスをコントロールに設定した場合を除き、TRUE を返します。
}

void CSerialPortTestMFC03Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// ダイアログに最小化ボタンを追加する場合、アイコンを描画するための
//  下のコードが必要です。ドキュメント/ビュー モデルを使う MFC アプリケーションの場合、
//  これは、Framework によって自動的に設定されます。

void CSerialPortTestMFC03Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 描画のデバイス コンテキスト

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// クライアントの四角形領域内の中央
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// アイコンの描画
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// ユーザーが最小化したウィンドウをドラッグしているときに表示するカーソルを取得するために、
//  システムがこの関数を呼び出します。
HCURSOR CSerialPortTestMFC03Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

// OKボタン押下イベント
void CSerialPortTestMFC03Dlg::OnBnClickedOk()
{
    StartTasks();

    // CDialogEx::OnOK();
    return;
}

// キャンセルボタン押下イベント
void CSerialPortTestMFC03Dlg::OnBnClickedCancel()
{
    isRecvThreadTerminated = TRUE;
    // CDialogEx::OnCancel();
    return;
}

/**
 * @brief シリアル通信の初期化処理を行います。
 * @return 処理結果 TRUE:成功/FALSE:失敗
 */
BOOL CSerialPortTestMFC03Dlg::InitSerial()
{
    // シリアルポートをオープンする。
    serialHandle = CreateFile(
        _T("COM3"),
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        0);

    // シリアルポートがオープンできない場合は終了
    if (serialHandle == INVALID_HANDLE_VALUE) return FALSE;

    // シリアルポートの通信条件を取得する
    DCB dcb;
    ZeroMemory(&dcb, sizeof(dcb));
 
    // シリアルポートの通信条件が取得できない場合は終了
    if (!GetCommState(serialHandle, &dcb)) {
        return UninitSerial();
    }

    // シリアル通信の入出力バッファをクリアする
    PurgeComm(serialHandle, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);

    // シリアルポートの通信条件を設定する
    SetSerialPortSettings(&dcb);

    // シリアル通信の設定をする
    if (!SetCommState(serialHandle, &dcb)) {
        return UninitSerial();
    }

    // シリアル通信のタイムアウトパラメータを取得する
    COMMTIMEOUTS timeouts;
    ZeroMemory(&timeouts, sizeof(timeouts));

    // シリアル通信のタイムアウトパラメータの取得でエラーの場合は終了
    if (!GetCommTimeouts(serialHandle, &timeouts)) {
        return UninitSerial();
    }

    // シリアル通信のタイムアウトパラメータを再設定する
    SetTimeoutSettings(&timeouts);

    // シリアル通信のタイムアウトパラメータの再設定でエラーの場合は終了
    if (!SetCommTimeouts(serialHandle, &timeouts)) {
        return UninitSerial();
    }

    // シリアル通信の拡張機能を設定します。
    EscapeCommFunction(serialHandle, SETRTS);

    return TRUE;
}

/**
 * @brief シリアル通信の終了処理を行います。
 * @return 処理結果 TRUE:成功/FALSE:失敗 ※ここでは常に成功としています。
 */
BOOL CSerialPortTestMFC03Dlg::UninitSerial()
{
    try {
        // シリアルのハンドルをクローズする
        CloseHandle(serialHandle);
        serialHandle = NULL;
    }
    catch (...) {
        if (serialHandle) serialHandle = NULL;
    }
    return FALSE;
}

/**
 * @brief 受信スレッドが停止した時に呼び出されます。
 * @param [in] wParam パラメータ(未使用)
 * @param [in] lParam パラメータ(未使用)
 * @return 処理結果 0:成功/0以外:失敗 ※ここでは常に成功にしています。
 */
LRESULT CSerialPortTestMFC03Dlg::OnRecvThreadTerminated(WPARAM wParam, LPARAM lParam)
{
    UninitSerial();
    return 0;
}

BOOL CSerialPortTestMFC03Dlg::PlanTask(shared_ptr<HANDLE> hsp)
{
    // 5ms単位で計測値を取得する
    auto abs_time = chrono::system_clock::now() + chrono::milliseconds(5);
    do {
        this_thread::sleep_until(abs_time);

        //*** TODO:シリアルポートからデータを受信 ***//

    } while (!isRecvThreadTerminated);

    // スレッド停止処理を呼び出します。
    this->PostMessage(WM_USER_READ_THREAD_TERMINATE);
    return TRUE;
}

void CSerialPortTestMFC03Dlg::OnBnClickedButton1()
{
    CDialogEx::OnOK();
}

// シリアルポートの通信条件を設定
void CSerialPortTestMFC03Dlg::SetSerialPortSettings(DCB* dcb) {
    dcb->fBinary = TRUE;
    dcb->BaudRate = 19200;
    dcb->fParity = FALSE;
    dcb->Parity = NOPARITY;
    dcb->ByteSize = 8;
    dcb->StopBits = ONESTOPBIT;
    dcb->fOutxCtsFlow = FALSE;
    dcb->fOutxDsrFlow = FALSE;
    dcb->fDsrSensitivity = FALSE;
    dcb->fTXContinueOnXoff = FALSE;
    dcb->fOutX = FALSE;
    dcb->fInX = FALSE;
    dcb->fDtrControl = DTR_CONTROL_ENABLE;
    dcb->fRtsControl = RTS_CONTROL_HANDSHAKE;
    dcb->fNull = FALSE;
    dcb->EofChar = '\r\n';
}

// シリアル通信のタイムアウトパラメータを再設定
void CSerialPortTestMFC03Dlg::SetTimeoutSettings(COMMTIMEOUTS* timeouts) {
    timeouts->ReadIntervalTimeout = MAXDWORD;
    timeouts->ReadTotalTimeoutMultiplier = 0;
    timeouts->ReadTotalTimeoutConstant = 10000;
    timeouts->WriteTotalTimeoutMultiplier = 0;
    timeouts->WriteTotalTimeoutConstant = 10;
}

void CSerialPortTestMFC03Dlg::NoneTask() {
    return;
}

BOOL CSerialPortTestMFC03Dlg::StartTasks() {

    BOOL result = FALSE;
    exception_ptr exptr;

    shared_ptr<HANDLE> hsp = make_shared<HANDLE>(serialHandle);
    thread thd{ [&] {
        try {
            result = PlanTask(hsp);
        } catch (...) {
          exptr = current_exception();
        }
    }};

    thd.join();
    if (exptr) // 例外処理を記述する

    return TRUE;
}