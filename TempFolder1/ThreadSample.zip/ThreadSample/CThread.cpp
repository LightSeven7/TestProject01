#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "FormAppTest09.h"

int ThreadPriority[5] = { THREAD_PRIORITY_LOWEST,
						THREAD_PRIORITY_BELOW_NORMAL,
						THREAD_PRIORITY_NORMAL,
						THREAD_PRIORITY_ABOVE_NORMAL,
						THREAD_PRIORITY_HIGHEST };

void __ThreadFunc(CThread* thread) { thread->ThreadFunc(); }

CThread::CThread()
{
	threadHandle = NULL;
	running = stopreq = suspension = 0;
	interval(1000);
}

CThread::~CThread()
{
	kill();
}

void CThread::ThreadFunc()
{
	while (stopreq == 0)
	{
		printf("Thread running. %d\n", threadID);
		if (stime > 0) Sleep(stime);
	}

	printf("Thread quitting. %d\n", threadID);
	CloseHandle(threadHandle);
	threadHandle = NULL;
}

void CThread::sleep(int n)
{
	if (threadHandle != NULL) sleep(n);
}

void CThread::start()
{
	if (threadHandle == NULL) {
		threadHandle = CreateThread(0, 0, 
			(LPTHREAD_START_ROUTINE)__ThreadFunc, this, 0, &threadID);
	}
}

void CThread::stop()
{
	if (threadHandle != NULL) stopreq = 1;
}

void CThread::kill()
{
	if (threadHandle != NULL)
	{
		TerminateThread(threadHandle, 0);
		CloseHandle(threadHandle);
		threadHandle = NULL;
		running = 0;
	}
}

void CThread::priority(int n)
{
	if ((threadHandle != NULL) && (1 <= n) && (n <= 5))
		SetThreadPriority(threadHandle, ThreadPriority[n - 1]);
}

int CThread::priority()
{
	if (threadHandle != NULL)
		return GetThreadPriority(threadHandle) + 1;
	else
		return int(0);
}

void CThread::suspend()
{
	if ((threadHandle != NULL) && (suspension == 0))
	{
		SuspendThread(threadHandle);
	}
	suspension = 0;
}

void CThread::resume()
{
	if ((threadHandle != NULL) && (suspension == 1))
	{
		ResumeThread(threadHandle);
	}
	suspension = 0;
}

CThreads::CThreads(int n)
{
	NoThreadsMax = n;
	NoThreads = 0;
	threads = (CThread**)malloc(sizeof(CThread*) * n);
}

CThreads::~CThreads()
{
	free(threads);
}

void CThreads::add(CThread* thread)
{
	if (NoThreads < NoThreadsMax) threads[NoThreads] = thread;
	NoThreads++;
}

void CThreads::start()
{
	for (DWORD n = 0; n < NoThreads; n++)
		threads[n]->start();
}

void CThreads::wait()
{
	HANDLE* threadHandles = (HANDLE*)malloc(sizeof(HANDLE) *NoThreads);
	for (DWORD n = 0; n < NoThreads; n++)
		threadHandles[n] = threads[n]->threadHandle;

	if (threadHandles != NULL)
	{
		WaitForMultipleObjects(NoThreads, threadHandles, TRUE, INFINITE);
		free(threadHandles);
	}
}
